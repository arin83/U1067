%this function will delete the files present in your sysem as enumerated in
%the input variable 'listOFfiles' or by calling uigetfile function after
%asking for confirmation.
%
%function usage:
%(1) [status message]=batchDelete(listOFfiles,path) where 'listOFfile' is a cell
%string enumerating the nale of files to be delated and 'pat' is a character
%vector indicating the path. Output message will inform on the outcome of
%the operation.
%(2) [status message]=batchDelete will call 'uigetfile' function to allow you
%choose from your system the files to be deleted (with multiselection
%option on)
%(3) [status message]=batchDelete(fullFilePath) where 'fullFilePath' is a cell
%string enumerating the full path and name of files to be deleted.
%
% -------------------------------------------------------------------------
% By Arin Marchesi
% Kanazawa University NanoLSI
% Kanazawa, 920-1192
% 26-April-2020
% written on MAtlab 2017a
% ------------------------------------------------------------------------




function [status, msg]=batchDelete(varargin)

narginchk(0,3)

%sort and check input argument

if nargin==0
    [filelist filepath]=uigetfile('*.*','Select files to be deleted','MultiSelect','on');
    ndata=numel(filelist);
    if isequal(filelist,0)
        status=0;
        msg=('Deletion failed');
        return
    end
end

if nargin==1        
    fullfilepathN=varargin{1};
    validateattributes(fullfilepathN,{'cell','char'},{'nonempty','vector'},...
        mfilename,'fullFilepathList',1)
    ndata=numel(fullfilepathN);
end

if nargin>1
    
    filelist=varargin{1};
    validateattributes(filelist,{'cell','char'},{'nonempty','vector'},...
        mfilename,'fileList',1)
    
    filepath=varargin{2};
    validateattributes(filepath,{'char','string'},{'nonempty'},...
        mfilename,'filepath',2)
    ndata=numel(filelist);
   
    if nargin==3
        option=varargin{3};
        validateattributes(option,{'numeric'},{'nonempty'},...
        mfilename,'option',3)
    end
end

if ~exist('option','var')
    option=1;
end

%close all open files to grant permission for deleting
fclose('all');

%ask for confirmation before proceedign with files delation

if option
    question=sprintf('Do you want to delete %d files from your system?',ndata);
    myicon=imread('Trump1.jpg');
    Def.IconString='custom';
    Def.IconData=myicon;
    Def.Default='Continue';
    fundlg=buttondlg(question,'Delete data','Abort','Continue',Def);
else
    fundlg='Continue';
end

switch fundlg
    
    case 'Abort'
        msg = 'Batch action aborted'; 
        status=0;
        warning(msg)
        return
        
    case 'Continue'     
        
        %construct the full path and delete files
        
        counter=0;
        
        for k=1:ndata
            
            if nargin==1
                fullfilepath=fullfilepathN{k};
            else
                fullfilepath=fullfile(filepath,filelist{k});
            end
            
            if exist(fullfilepath,'file')==2
                delete(fullfilepath)
            else
                counter=counter+1;
            end
        end
        
        if counter==0
            msg = sprintf('%d / %d files succesfully deleted from your computer!',ndata-counter,ndata);
            status=1;
        else
            msg = sprintf('%d / %d files were not found!',counter,ndata);
            status=1;
        end

end




%update files present in the listbox 1 and listbox2




    