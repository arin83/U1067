% this function perform an alignment among two sequences using 
% a modified cross-correlation (CC), optimized for 1D projections. Differently from xcorr function it uses 
% convolution to do so. Hence, the data do not need to be detrended or offset-adjusted.

%this function might have mistakes in it's implementation


function [CC, lagv]= ccorCC(sequence, kernel)

kernel=double(kernel);
sequence=double(sequence);



%NCC calculation



  num= conv2(sequence,rot90(kernel,2),'same');
 % den=(conv2(ones(size(sequence)),ones(size(kernel)),'same'));
%  CC=(num./(den));
  CC=num;
 % CC=kaiser(numel(CC),1.5).*CC;
%NCC=num;
%  pad=floor(kernSize/4);
%  NCC(1:pad)=0;
%  NCC(end-pad:end)=0;


lagv=-floor((numel(kernel)-1)/2):1:length(sequence)-((round(numel(kernel)/2)));