function varargout = asd2tiff_GUI(varargin)
% ASD2TIFF_GUI MATLAB code for asd2tiff_GUI.fig
%      ASD2TIFF_GUI, by itself, creates a new ASD2TIFF_GUI or raises the existing
%      singleton*.
%
%      H = ASD2TIFF_GUI returns the handle to a new ASD2TIFF_GUI or the handle to
%      the existing singleton*.
%
%      ASD2TIFF_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ASD2TIFF_GUI.M with the given input arguments.
%
%      ASD2TIFF_GUI('Property','Value',...) creates a new ASD2TIFF_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before asd2tiff_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to asd2tiff_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help asd2tiff_GUI

% Last Modified by GUIDE v2.5 27-Aug-2020 11:58:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @asd2tiff_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @asd2tiff_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before asd2tiff_GUI is made visible.
function asd2tiff_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to asd2tiff_GUI (see VARARGIN)

% Choose default command line output for asd2tiff_GUI
handles.output = hObject;

%set default path to desktop and remove "Listbox" label from listbox
handles.multiviewers=0;
handles.myPathSearch=winqueryreg('HKEY_CURRENT_USER', 'Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders', 'Desktop');
cd(handles.myPathSearch);
check1=get(handles.listbox1,'string');
check2=get(handles.listbox2,'string');

if numel(check2)==1
    if find(strcmp(check2,'Listbox'))
    set(handles.listbox2,'String',{'Empty'});
    end
end

if numel(check1)==1
    if find(strcmp(check1,'Listbox'))
    set(handles.listbox1,'String',{'Empty'});
    end
end
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes asd2tiff_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = asd2tiff_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%retrive the selected file name and the path

contents = cellstr(get(hObject,'String')); 
filename=contents{get(hObject,'Value')};

isSmat=contains(filename,'.smat');

if isfield(handles, 'pathList')
    pathList=handles.pathList;
    folder_name=pathList{get(hObject,'Value')};
else
    msg = 'Please select a folder!!.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

%check if the user want to display the video, and which channel

flag=get(handles.check_viewer,'Value');

whichCh1=get(handles.radio_ch1,'Value');
whichCh2=get(handles.radio_ch2,'Value');

if whichCh1
    channel=1;
elseif whichCh2
    channel=2;
else
    channel=12;
end

filepath = fullfile(folder_name,filename);

if flag
    
    switch channel
        
        case 1
            
            
            %check which kinf of file we are dealing with
            
            if isSmat
                filename1=[filename]; 
                load(filepath,'-mat')
                video=AFMdata.ch1;
                if isfield(AFMdata,'header')
                    header=AFMdata.header;
                end
                if isfield(AFMdata,'optional')
                    optional=AFMdata.optional;                   
                end
            else
                filename1=['Ch1 ' filename]; 
                [video, header]=loadASD(filepath);
            end
            
            if handles.multiviewers==0
                if isfield(handles,'vCh1')&&ishandle(handles.vCh1)
                    myhandles=guidata(handles.vCh1);
                    viewer_GUI('cleanup',handles.vCh1,[],myhandles);
                    myhandles=guidata(handles.vCh1); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh1,[],myhandles,video);
                    set(handles.vCh1,'Name',filename1)
                    
                else
                    handles.vCh1=viewer_GUI(video,filename1,header);
                end
                
                
            else
                handles.vCh1=viewer_GUI(video,filename1,header);
            end
            
            %set up optional information
            
            if exist('optional','var')==1
                myhandles=guidata(handles.vCh1);
                setappdata(myhandles.hfig,'optional',optional)
                viewer_GUI('setupoption',handles.vCh1,[],myhandles)
            end            
            
        case 2
            
            if isSmat
                msg = '!!Multichannel option not supported for .smat file format!!';
                set(handles.text_mssg,'string',msg,'ForegroundColor','r')
                warning(msg)
                
                set(handles.radio_ch1,'Value',1);
                listbox1_Callback(hObject, eventdata, handles)
                guidata(hObject,handles);
                return
            end
            
            filename2=['Ch2 ' filename];            
            [~, header, video]=loadASD(filepath);          
         
             if handles.multiviewers==0
                if isfield(handles,'vCh2')&&ishandle(handles.vCh2)
                    %refresh channel 2 window
                    myhandles=guidata(handles.vCh2);
                    viewer_GUI('cleanup',handles.vCh2,[],myhandles);
                    myhandles=guidata(handles.vCh2); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh2,[],myhandles,video);
                    set(handles.vCh2,'Name',filename2)
                    
                else
                    handles.vCh2=viewer_GUI(video,filename2,header);
                end
             else
                 handles.vCh2=viewer_GUI(video,filename2,header);
             end
             
            
        case 12
            
             if isSmat
                msg = '!!Multichannel option not supported for .smat file format!!';
                set(handles.text_mssg,'string',msg,'ForegroundColor','r')
                warning(msg)
                
                set(handles.radio_ch1,'Value',1);
                listbox1_Callback(hObject, eventdata, handles)
                guidata(hObject,handles);
                return
             end
            
            filename1=['Ch1 ' filename];
            filename2=['Ch2 ' filename];            
            [video1, header, video2]=loadASD(filepath);
            if handles.multiviewers==0
                if isfield(handles,'vCh1')&&ishandle(handles.vCh1)...
                       &&isfield(handles,'vCh2')&&ishandle(handles.vCh2) 
                    %refresh channel 2 window
                    myhandles=guidata(handles.vCh2);
                    viewer_GUI('cleanup',handles.vCh2,[],myhandles);
                    myhandles=guidata(handles.vCh2); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh2,[],myhandles,video2);
                    set(handles.vCh2,'Name',filename2)
                    
                    %refresh channel 1 window
                     myhandles=guidata(handles.vCh1);
                    viewer_GUI('cleanup',handles.vCh1,[],myhandles);
                    myhandles=guidata(handles.vCh1); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh1,[],myhandles,video1);
                    set(handles.vCh1,'Name',filename1)
                    
                else
                    handles.vCh1=viewer_GUI(video1,filename1,header);
                    %             data=guidata(h1);
                    guidata(hObject,handles);
                    handles=guidata(hObject);
                    
                    %handles=guidata(hObject);
                    handles.vCh2=viewer_GUI(video2,filename2,header);
                end
            else
                handles.vCh1=viewer_GUI(video1,filename1,header);
                %             data=guidata(h1);
                guidata(hObject,handles);
                handles=guidata(hObject);
                
                %handles=guidata(hObject);
                handles.vCh2=viewer_GUI(video2,filename2,header);
            end
            
     
    end
    
    %update header information if "File header editor is open"
    
    if isfield(handles,'Info')&&ishandle(handles.Info)
        myhandlesI=guidata(handles.Info);
        info_GUI('info_GUI_OpeningFcn',handles.Info,[],myhandlesI,...
            header,filename)
    end
    
    guidata(hObject,handles);
    
else
    
    if isfield(handles,'Info')&&ishandle(handles.Info)
        myhandlesI=guidata(handles.Info);
        
        if isSmat
            load(filepath,'-mat')               
                if isfield(AFMdata,'header')
                    header=AFMdata.header;
                else
                    return
                end
        else
            header=loadASDh(filepath);
        end
        
        info_GUI('info_GUI_OpeningFcn',handles.Info,[],myhandlesI,...
            header,filename)
    end
    
end
% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2

%retrive the selected file name and the folder

%fet selected file in Listbox2
contents = cellstr(get(hObject,'String'));
filename=contents{get(hObject,'Value')};
%get the path

isSmat=contains(filename,'.smat');

if isfield(handles, 'pathList2')
    pathList2=handles.pathList2;
    folder_name=pathList2{get(hObject,'Value')};
else
    msg = 'Please select a folder!!.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end



%check if the user want to display the video, and which channel

flag=get(handles.check_viewer,'Value');

whichCh1=get(handles.radio_ch1,'Value');
whichCh2=get(handles.radio_ch2,'Value');

if whichCh1
    channel=1;
elseif whichCh2
    channel=2;
else
    channel=12;
end

filepath = fullfile(folder_name,filename);

if flag
    
    switch channel
        
        case 1
            
            if isSmat
                filename1=[filename]; 
                load(filepath,'-mat')
                video=AFMdata.ch1;
                if isfield(AFMdata,'header')
                    header=AFMdata.header;
                end
                if isfield(AFMdata,'optional')
                    optional=AFMdata.optional;                   
                end
            else
                filename1=['Ch1 ' filename]; 
                [video, header]=loadASD(filepath);
            end
            
            if handles.multiviewers==0
                if isfield(handles,'vCh1')&&ishandle(handles.vCh1)
                    myhandles=guidata(handles.vCh1);
                    viewer_GUI('cleanup',handles.vCh1,[],myhandles);
                    myhandles=guidata(handles.vCh1); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh1,[],myhandles,video);
                    set(handles.vCh1,'Name',filename1)
                else
                    handles.vCh1=viewer_GUI(video,filename1,header);
                end
                                
            else
                handles.vCh1=viewer_GUI(video,filename1,header);
            end
            
            %set up optional information
            
            if exist('optional','var')==1
                myhandles=guidata(handles.vCh1);
                setappdata(myhandles.hfig,'optional',optional)
                viewer_GUI('setupoption',handles.vCh1,[],myhandles)
            end 
            
            
        case 2
            
            if isSmat
                msg = '!!Multichannel option not supported for .smat file format!!';
                set(handles.text_mssg,'string',msg,'ForegroundColor','r')
                warning(msg)
                
                set(handles.radio_ch1,'Value',1);
                listbox1_Callback(hObject, eventdata, handles)
                guidata(hObject,handles);
                return
            end
            
            filename2=['Ch2 ' filename];            
            [~, header, video]=loadASD(filepath);          
         
             if handles.multiviewers==0
                if isfield(handles,'vCh2')&&ishandle(handles.vCh2)
                    %refresh channel 2 window
                    myhandles=guidata(handles.vCh2);
                    viewer_GUI('cleanup',handles.vCh2,[],myhandles);
                    myhandles=guidata(handles.vCh2); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh2,[],myhandles,video);
                    set(handles.vCh2,'Name',filename2)
                    
                else
                    handles.vCh2=viewer_GUI(video,filename2,header);
                end
             else
                 handles.vCh2=viewer_GUI(video,filename2,header);
             end
             
            
        case 12
            
            if isSmat
                msg = '!!Multichannel option not supported for .smat file format!!';
                set(handles.text_mssg,'string',msg,'ForegroundColor','r')
                warning(msg)
                
                set(handles.radio_ch1,'Value',1);
                listbox1_Callback(hObject, eventdata, handles)
                guidata(hObject,handles);
                return
            end
            
            filename1=['Ch1 ' filename];
            filename2=['Ch2 ' filename];            
            [video1, header, video2]=loadASD(filepath);
            if handles.multiviewers==0
                if isfield(handles,'vCh1')&&ishandle(handles.vCh1)...
                       &&isfield(handles,'vCh2')&&ishandle(handles.vCh2) 
                    %refresh channel 2 window
                    myhandles=guidata(handles.vCh2);
                    viewer_GUI('cleanup',handles.vCh2,[],myhandles);
                    myhandles=guidata(handles.vCh2); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh2,[],myhandles,video2);
                    set(handles.vCh2,'Name',filename2)
                    
                    %refresh channel 1 window
                     myhandles=guidata(handles.vCh1);
                    viewer_GUI('cleanup',handles.vCh1,[],myhandles);
                    myhandles=guidata(handles.vCh1); %refres myhandles
                    setappdata(myhandles.hfig,'info',header)
                    viewer_GUI('setup',handles.vCh1,[],myhandles,video1);
                    set(handles.vCh1,'Name',filename1)
                    
                else
                    handles.vCh1=viewer_GUI(video1,filename1,header);
                    %             data=guidata(h1);
                    guidata(hObject,handles);
                    handles=guidata(hObject);
                    
                    %handles=guidata(hObject);
                    handles.vCh2=viewer_GUI(video2,filename2,header);
                end
            else
                handles.vCh1=viewer_GUI(video1,filename1,header);
                %             data=guidata(h1);
                guidata(hObject,handles);
                handles=guidata(hObject);
                
                %handles=guidata(hObject);
                handles.vCh2=viewer_GUI(video2,filename2,header);
            end
            
     
    end
    
    %update header information if "File header editor is open"
    
    if isfield(handles,'Info')&&ishandle(handles.Info)
        myhandlesI=guidata(handles.Info);
        info_GUI('info_GUI_OpeningFcn',handles.Info,[],myhandlesI,...
            header,filename)
    end
    
    guidata(hObject,handles);
    
else
    
    if isfield(handles,'Info')&&ishandle(handles.Info)
        myhandlesI=guidata(handles.Info);
        
        if isSmat
            load(filepath,'-mat')               
                if isfield(AFMdata,'header')
                    header=AFMdata.header;
                else
                    return
                end
        else
            header=loadASDh(filepath);
        end
        
        info_GUI('info_GUI_OpeningFcn',handles.Info,[],myhandlesI,...
            header,filename)
    end
        
    
end
% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in push_convert.
function push_convert_Callback(hObject, eventdata, handles)
% hObject    handle to push_convert (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
whichCh1=get(handles.radio_ch1,'Value');
whichCh2=get(handles.radio_ch2,'Value');

if whichCh1
    channel=1;
elseif whichCh2
    channel=2;
else
    channel=12;
end


whichlist=get(handles.radio_dire,'Value');

if whichlist
    asdfiles = cellstr(get(handles.listbox1,'String'));
    if isfield(handles, 'pathList')
        paths4files=handles.pathList;
    else
        msg = 'Please select a folder!!.';
        set(handles.text_mssg,'string',msg,'ForegroundColor','r')
        warning(msg)
        return
    end
else
    asdfiles = cellstr(get(handles.listbox2,'String'));
    
    if isfield(handles, 'pathList2')
        paths4files=handles.pathList2;
    else
        msg = 'Please select a folder!!.';
        set(handles.text_mssg,'string',msg,'ForegroundColor','r')
        warning(msg)
        return
    end
end

check1=cell2mat(strfind(asdfiles,'.asd'));
check2=cell2mat(strfind(asdfiles,'.smat'));

if isempty(check1)||isempty(check2)
    msg = 'No ASD or SMAT files found. Batch processing aborted!!.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg) 
    return
end

msg=batchasd4GUI(paths4files,asdfiles,channel);
set(handles.text_mssg,'string',msg,'ForegroundColor','k')



% --- Executes on button press in pushb_add.
function pushb_add_Callback(hObject, eventdata, handles)
% hObject    handle to pushb_add (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
contents = cellstr(get(handles.listbox1,'String')); 
contPath = handles.pathList; 
newFile=contents{get(handles.listbox1,'Value')};
newPath=contPath{get(handles.listbox1,'Value')};
oldList=cellstr(get(handles.listbox2,'String')); %read what is already present

%read old paths for lsitobx2
if isfield(handles,'pathList2')
    oldPath=handles.pathList2;
else
    oldPath={};
end

%when the listbox is empty, the string 'listbox' appears. Check weather is
%the case and also weather the target file is already present

check0=find(strcmp(oldList,'Empty'));
check=find(strcmp(oldList,char(newFile)));

%if the string "listbox" is repsent, lets delete it
if ~isempty(check0)
    oldList(check0)=[];
    set(handles.listbox2,'String',oldList);
end

%add to the list the new file and relative path at the bottom
fileList=oldList; fileList{end+1}=newFile;
pathList2=oldPath; pathList2{end+1}=newPath;

%issue a warning if the file is already present and exit the function
if ~isempty(check)
    msg1 = char(newFile);
    msg2 = " already added in the list!!!";
    msg =strcat(msg1,msg2);
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(char(msg))
    return
end

%update the playlist wit the new file
set(handles.listbox2,'String',fileList);
PlayList=get(handles.listbox2,'String');
set(handles.listbox2,'Value',numel(PlayList));
handles.pathList2=pathList2;

guidata(hObject, handles);

if numel(PlayList)>0
    set(handles.push_remove,'enable','on');
end

% --- Executes on button press in push_remove.
function push_remove_Callback(hObject, eventdata, handles)
% hObject    handle to push_remove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
contents = cellstr(get(handles.listbox2,'String'));
pathList2 = handles.pathList2;

if numel(contents)==0
    msg = '!!All files already deleted!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    set(hObject,'enable','off');
    return
end
    
sele=get(handles.listbox2,'Value');

if sele>1
    set(handles.listbox2,'Value',sele-1);
end

contents(sele)=[];
pathList2(sele)=[];

handles.pathList2=pathList2;

guidata(hObject, handles);

set(handles.listbox2,'String',contents);

% --------------------------------------------------------------------
function menu_load_Callback(hObject, eventdata, handles)
% hObject    handle to menu_load (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function menu_settings_Callback(hObject, eventdata, handles)
% hObject    handle to menu_settings (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





% --- Executes on button press in push_clear.
function push_clear_Callback(hObject, eventdata, handles)
% hObject    handle to push_clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%show the path of the selected file in lsitbox1

selection=get(handles.listbox1,'value');

if ~isfield(handles,'pathList')
    msg=('No path was found for the selected file');
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    return
end

pathList=handles.pathList;
folder_name=pathList(selection);

set(handles.text_mssg,'string',folder_name,'ForegroundColor','k')


% --- Executes on button press in check_viewer.
function check_viewer_Callback(hObject, eventdata, handles)
% hObject    handle to check_viewer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of check_viewer


% --------------------------------------------------------------------
function menu_asd_general_Callback(hObject, eventdata, handles)
% hObject    handle to menu_asd_general (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%maybe can be implemented in a function



% --------------------------------------------------------------------
function menu_loadTIFF_Callback(hObject, eventdata, handles)
% hObject    handle to menu_loadTIFF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_loadALL_Callback(hObject, eventdata, handles)
% hObject    handle to menu_loadALL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in push_comment.
function push_comment_Callback(hObject, eventdata, handles)
% hObject    handle to push_comment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%get selection from listbox1 and construct the file path


whichList=get(handles.radio_play,'Value');

if whichList
    try
        sele=get(handles.listbox2,'Value');
        files=get(handles.listbox2,'String');
        name=cellstr(files{sele});
        
        path_name=char(handles.pathList2{sele});
    catch
        msg=('Error. Please check reference directory and/or listbox');
        set(handles.text_mssg,'string',msg,'ForegroundColor','r')
        return
    end
else
    try
        sele=get(handles.listbox1,'Value');
        files=get(handles.listbox1,'String');
        name=cellstr(files{sele});
        
        path_name=char(handles.pathList{sele});
    catch
        msg=('Error. Please check reference directory and/or listbox');
        set(handles.text_mssg,'string',msg,'ForegroundColor','r')
        return
    end
end

fullfilepath=char(fullfile(path_name,name));
isSmat=contains(name,'.smat');

%load the old header
if isSmat
    load(fullfilepath,'-mat');
    
    if isfield(AFMdata,'header')
        info=AFMdata.header;
    else
        msg=('There are no metadata present in the file');
        set(handles.text_mssg,'string',msg,'ForegroundColor','r')
        return
    end
elseif contains(name,'.asd')
    info=loadASDh(fullfilepath);
else
    msg=('Unrecognized file format, can not read the header');
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    return
end
%open an input dialog box and request for modification

prompt = {'New comment'};
title='Edit comment';
numlines=[1 100];

if iscell(info.comment)
    default=regexprep(info.comment,'\s+',' ');
else
    default={regexprep(info.comment,'\s+',' ')};
end

answer = inputdlg(prompt, title, numlines,default);

if ~isempty(answer)
    comment=char(answer);
else
    return
end

if isSmat
    AFMdata.header.comment=comment;
    save(fullfilepath,'AFMdata')
else
    msg=modifyASDcomment(fullfilepath,comment);
    set(handles.text_mssg,'string',msg,'ForegroundColor','k')
end

clear info


% Update handles structure
guidata(hObject, handles);

% --------------------------------------------------------------------
function menu_actions_Callback(hObject, eventdata, handles)
% hObject    handle to menu_actions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in push_info.
function push_info_Callback(hObject, eventdata, handles)
% hObject    handle to push_info (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
contents = cellstr(get(handles.listbox1,'String')); 
filename=contents{get(handles.listbox1,'Value')};

if isfield(handles, 'pathList')
    pathList=handles.pathList;
    folder_name=pathList{get(handles.listbox1,'Value')};
else
    msg = 'Please select a folder!!.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

isSmat=contains(filename,'.smat');

if ~contains(filename,'.asd')&&~isSmat
    msg = 'No .asd or .smat file selected.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

filepath = fullfile(folder_name,filename);

if isSmat
    load(filepath,'-mat')
    if isfield(AFMdata,'header')
        header=AFMdata.header;
    else
        msg = 'No header found.';
        set(handles.text_mssg,'string',msg,'ForegroundColor','r')
        warning(msg)
        return
    end
else
    header=loadASDh(filepath);
end


clear fake

if ~(isfield(handles,'Info')&&ishandle(handles.Info))
    handles.Info=info_GUI(header, filename);
end

guidata(hObject, handles);




% --- Executes on key press with focus on figure1 or any of its controls.
function figure1_WindowKeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
 keyPressed = eventdata.Key;
 
 switch keyPressed
     
     case 'i'  %display file metadata
         % set focus to the button
         uicontrol(handles.push_info);
         % call the callback
         push_info_Callback(handles.push_info,[],handles);
         
     case 'x'  %move one frame forward
         
         if isfield(handles,'vCh1')&&ishandle(handles.vCh1)
             myhandles=guidata(handles.vCh1);
             frame=myhandles.frame;
             
             if frame<myhandles.nFrame
                 frame=frame+1;
             else
                 frame=1;
             end
             
             set(myhandles.slider1,'Value',frame);
             myhandles.frame=frame;
             viewer_GUI('displayI',handles.vCh1,[],myhandles);
             
         end
         
         clear myhandles
         
         if isfield(handles,'vCh2')&&ishandle(handles.vCh2)
             myhandles=guidata(handles.vCh2);
             frame=myhandles.frame;
             
             if frame<myhandles.nFrame
                 frame=frame+1;
             else
                 frame=1;
             end
             
             set(myhandles.slider1,'Value',frame);
             myhandles.frame=frame;
             viewer_GUI('displayI',handles.vCh2,[],myhandles);
             
         end
         
     case 'z' %move one frame backword
         
         
         if isfield(handles,'vCh1')&&ishandle(handles.vCh1)
             myhandles=guidata(handles.vCh1);
             frame=myhandles.frame;
             
             if frame>1
                 frame=frame-1;
             else
                 frame=myhandles.nFrame;
             end
             
             set(myhandles.slider1,'Value',frame);
             myhandles.frame=frame;
             viewer_GUI('displayI',handles.vCh1,[],myhandles);
             
         end
         
         clear myhandles
         
         if isfield(handles,'vCh2')&&ishandle(handles.vCh2)
             myhandles=guidata(handles.vCh2);
             frame=myhandles.frame;
             
             if frame>1
                 frame=frame-1;
             else
                 frame=myhandles.nFrame;
             end
             
             set(myhandles.slider1,'Value',frame);
             myhandles.frame=frame;
             viewer_GUI('displayI',handles.vCh2,[],myhandles);
             
         end
         
     case 's'  %synchronize to the same frame Ch1 and Ch2
         
         if isfield(handles,'vCh1')&&ishandle(handles.vCh1)
             
             if isfield(handles,'vCh2')&&ishandle(handles.vCh2)
                 
                 myhandles=guidata(handles.vCh1);
                 frame=myhandles.frame;
                 set(myhandles.slider1,'Value',frame);
                 viewer_GUI('displayI',handles.vCh1,[],myhandles);
                 
                 %synchronize the frame in Ch2 to Ch1
                 
                 myhandles2=guidata(handles.vCh2);
                 myhandles2.frame=frame;
                 set(myhandles2.slider1,'Value',frame);
                 viewer_GUI('displayI',handles.vCh2,[],myhandles2);
                 
             end
         end
         
     case 'rightarrow'
         %uicontrol(handles.pushb_add);
         pushb_add_Callback(hObject, eventdata, handles)
         
     case 'leftarrow'
         push_remove_Callback(hObject, eventdata, handles)
         
     case '1'
         fixbug=get(handles.listbox2,'Value');
         uicontrol(handles.listbox1);
         set(handles.listbox2,'Value',fixbug);
     case '2'
         fixbug=get(handles.listbox1,'Value');
         fixbug2=get(handles.listbox2,'Value');
         uicontrol(handles.listbox2);
         set(handles.listbox1,'Value',fixbug);
         set(handles.listbox2,'Value',fixbug2);
     
     case 'd'    %delete selected file
         
         %extract the file name to be deletaed
         
         fileList = cellstr(get(handles.listbox1,'String'));
         mychoice=get(handles.listbox1,'Value');
         
         myfile=fileList{mychoice};
         ndata=numel(myfile);  %in principle equal to 1
         
         %check what kinf of file we are dealing with and store extension
         
         if ndata==0||isempty(myfile)      
             msg = 'No file found. Please select a files!!.';
             set(handles.text_mssg,'string',msg,'ForegroundColor','r')
             warning(msg)
             return
         end
         
         %get the folder name to build the fullfilepath
         try
             pathList1=handles.pathList;
             folder_name=pathList1{mychoice};
         catch
             msg = 'Can''t find files path!!';
             set(handles.text_mssg,'string',msg,'ForegroundColor','r')
             warning(msg)
             return
         end
         
         [status,msg]=batchDelete(cellstr(myfile),folder_name,0);
         
         if status
             color='k';
         else
             color='r';
         end
         
         set(handles.text_mssg,'string',msg,'ForegroundColor',color)
         
         %check for existance of files and update files present in the listbox 1 
         
         fullpathList1=fullfile(pathList1',fileList);
         
         nfiles=length(fullpathList1);
         valid=zeros(nfiles,1);
         
         for k=1:nfiles
             
             check=exist(fullpathList1{k},'file');
             
             if check==2
                 valid(k)=1;
             else
                 valid(k)=0;
             end
         end
         
         newfilelist1=fileList(logical(valid));
         newpathlist1=pathList1(logical(valid));
         handles.pathList=newpathlist1;
         
         if status
             
             if isempty(newfilelist1)
                 msg = '!!No ASD file found in the selected folder-All files deleted(?)!!';
                 myicon = imread('Silvio1.png');
                 msgbox(msg,'Success, but...','custom',myicon);
                 fileList={};
             else
                 fileList= newfilelist1;
             end
             
             %reset listbox previous selections
             
             set(handles.listbox1,'String',fileList);
             sele=get(handles.listbox1,'Value');
             
             if sele>numel(fileList)
                 set(handles.listbox1,'Value',numel(fileList));
             end
             
             clear sele
             
             %udapte dispalyed image to the next file in the viewer
             
             guidata(hObject,handles);
             handles=guidata(hObject);
             
             listbox1_Callback(handles.listbox1, [], handles)
             
             %check weather the deleted file was present in the playlist
             %and delete it
             
             oldList=cellstr(get(handles.listbox2,'String'));
             check=find(strcmp(oldList,char(myfile)));
             
             if isempty(check)
                 return
             else
                 oldList(check)=[];
                 newList=oldList;
                 pathList2=handles.pathList2;
                 pathList2(check)=[];
                 %adjust selection to take account removal
                 sele=get(handles.listbox2,'Value');
                 
                 if sele>1
                     set(handles.listbox2,'Value',sele-1);
                     
                 end
             end
             handles.pathList2=pathList2;
             set(handles.listbox2,'String',newList);
         end
         
         guidata(hObject, handles);                  
         
 end


% --------------------------------------------------------------------
function ctxmenu_multi_Callback(hObject, eventdata, handles)
% hObject    handle to ctxmenu_multi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.multiviewers=1;
set(handles.ctxmenu_single,'Checked','off')
set(hObject,'Checked','on')
guidata(hObject, handles);
% --------------------------------------------------------------------
function ctxmenu_single_Callback(hObject, eventdata, handles)
% hObject    handle to ctxmenu_single (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.multiviewers=0;
set(handles.ctxmenu_multi,'Checked','off')
set(hObject,'Checked','on')
guidata(hObject, handles);
% --------------------------------------------------------------------
function viewer_options_Callback(hObject, eventdata, handles)
% hObject    handle to viewer_options (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(hObject, handles);


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_path_desktop_Callback(hObject, eventdata, handles)
% hObject    handle to menu_path_desktop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.myPathSearch=winqueryreg('HKEY_CURRENT_USER', 'Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders', 'Desktop');
cd(handles.myPathSearch);
set(hObject,'Checked','On');
set(handles.menu_path_user,'Checked','Off');
set(handles.menu_path_last,'Checked','Off');
guidata(hObject, handles);
% --------------------------------------------------------------------
function menu_path_user_Callback(hObject, eventdata, handles)
% hObject    handle to menu_path_user (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.myPathSearch = uigetdir(handles.myPathSearch,'Define your searching path');
cd(handles.myPathSearch);
set(hObject,'Checked','On');
set(handles.menu_path_desktop,'Checked','Off');
set(handles.menu_path_last,'Checked','Off');
guidata(hObject, handles);
% --------------------------------------------------------------------
function menu_path_last_Callback(hObject, eventdata, handles)
% hObject    handle to menu_path_last (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Checked','On');
set(handles.menu_path_desktop,'Checked','Off');
set(handles.menu_path_user,'Checked','Off');
guidata(hObject, handles);


% --------------------------------------------------------------------
function menu_empty_playlist_Callback(hObject, eventdata, handles)
% hObject    handle to menu_empty_playlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 set(handles.listbox2,'Value',1);
 set(handles.listbox2,'String',{});
 
 if isfield(handles,'pathList2')
     handles=rmfield(handles,'pathList2');
 end
 
 guidata(hObject, handles);
% --------------------------------------------------------------------
function menu_delete_Callback(hObject, eventdata, handles)
% hObject    handle to menu_delete (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%extract the files name and path to be deletaed

fileList = cellstr(get(handles.listbox2,'String'));
ndata=numel(fileList);

if isfield(handles, 'pathList2')
    pathList2=handles.pathList2;
else
    msg = 'Can not find the path for the file!!.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

%check what kinf of file we are dealing with and store extension

if ndata==0
    msg = 'No file found in the Playlist. Please select some files!!.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg) 
    return
end

fullpathList=fullfile(pathList2',fileList);
[status,msg]=batchDelete(fullpathList);

if status
    color='k';
else
    color='r';
end

set(handles.text_mssg,'string',msg,'ForegroundColor',color)

%update files present in the listbox 1 and listbox2

%get all the files with the full path from listbox1

fileList1=get(handles.listbox1,'String');
pathList1=handles.pathList;
fullpathList1=fullfile(pathList1',fileList1);

nfiles=length(fullpathList1);
valid=zeros(nfiles,1);

        %check weather these files exist and construct the updated list of
        %files to be dispalyed in the listbox1

        for k=1:nfiles
            
            check=exist(fullpathList1{k},'file');
            
            if check==2
                valid(k)=1;
            else
                valid(k)=0;
            end
        end

newfilelist1=fileList1(logical(valid));
newpathList1=pathList1(logical(valid));
handles.pathList=newpathList1;

if status
    
    if isempty(newfilelist1)
        msg = '!!No ASD file found in the selected folder-All files deleted(?)!!';
        myicon = imread('Silvio1.png');
        msgbox(msg,'Success, but...','custom',myicon);
        fileList={};
    else
        fileList= newfilelist1;
    end
    
    %reset listbox previous selections
    set(handles.listbox1,'String',fileList);
    set(handles.listbox1,'Value',1);
    set(handles.listbox2,'Value',1);
    set(handles.listbox2,'String',{});
    handles.pathList2=[];
end

guidata(hObject, handles);


% --------------------------------------------------------------------
function menu_export_play_Callback(hObject, eventdata, handles)
% hObject    handle to menu_export_play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%get the list of files and paths. Make sure there is at least one element.
filelist=get(handles.listbox2,'String');

if numel(filelist)==1
    if find(strcmp(filelist,'Empty'))
        msg = 'No file found in the Playlist. Nothing to be saved!!.';
        fun=randperm(3);
        if fun(1)==3
            image=imread('What1.jpg');
            figure('Name','Congratulations!You win the lottery','NumberTitle','off')
            imshow(image)
        end
        set(handles.text_mssg,'string',msg,'ForegroundColor','r')
        return
    end
end

filepath=handles.pathList2;

%make the structure variable and save it
myplaylist=struct('filePath',filepath,'fileList',filelist');

uisave('myplaylist','myPlayList.mat')


% --------------------------------------------------------------------
function menu_load_playlist_Callback(hObject, eventdata, handles)
% hObject    handle to menu_load_playlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%upload playlist and make sure has the file names and paths information
[file, path]=uigetfile('*.mat','Selet your playlist');

if isequal(file,0)
    msg='Loading aborted: user selected cancel';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r');
end

fullfilepath=fullfile(path,file);
playlist=load(fullfilepath);
playlist=playlist.myplaylist;
newcolor=sprintf('<HTML><BODY bgcolor="%s">', 'red');
handles.newcolor = newcolor;
set(handles.listbox1,'Value',1);

if isfield(playlist,'fileList')
    filelist={playlist.fileList}';
else
    msg='Improper matlab file. fileList structure missing!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r');
    return
end

if isfield(playlist,'filePath')
    filepath={playlist.filePath};
else
    msg='Path info missing!Select action>retrive path to locate the files';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r');
    
    %make a fake path for the files, to avoid possible error trigggering
    fakepathList=cell(6,1);
    fakepathList(:)={pwd};
    handles.pathList=fakepathList;
    
    %change color of the string in listbox to red
        
    mycolors=cell(numel(filelist),1);
    mycolors(:)={newcolor};
    newcoloredlist=strcat(mycolors,filelist);
    set(handles.listbox1,'String',newcoloredlist);
    guidata(hObject, handles);
    return
end

%check the correctness of all paths and keep only the valid ones

fullpathList=fullfile(filepath',filelist);

nfiles=length(fullpathList);
newfilelist=cell(nfiles,1);
valid=zeros(nfiles,1);

        for k=1:nfiles
            
            check=exist(fullpathList{k},'file');
            
            if check==2
                valid(k)=1;
                newfilelist(k)=filelist(k);
            else
                valid(k)=0;
                newfilelist(k)=strcat(newcolor,filelist(k));
            end
        end



set(handles.listbox1,'String',newfilelist)

if nfiles>sum(valid)
    color='r';
else
    color='k';
end

msg=['Found ' num2str(sum(valid)) ' files, out of ' num2str(nfiles) '!!'];
set(handles.text_mssg,'string',msg,'ForegroundColor',color);

%make a table to diplay the results

r=struct('paths',filepath','files',filelist,'status',num2cell(valid));
rTable = struct2table(r);
disp(rTable);


handles.pathList=filepath;
guidata(hObject, handles);


% --------------------------------------------------------------------
function menu_retrivePath_Callback(hObject, eventdata, handles)
% hObject    handle to menu_retrivePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%find which element in the file directory is highlighted in red

if ~isfield(handles,'newcolor')
    return
end

%get list of files and paths and color html text
filelist=get(handles.listbox1,'string');
pathList=handles.pathList;

highlighted=handles.newcolor;
check=contains(filelist,highlighted);
i=find(check);
nfiles=numel(i);

%remove highlighting html part from the string to search afterword the file

for k=1:nfiles
    newname=char(filelist(i(k)));
    newname=strrep(newname,highlighted,'');
    filelist{i(k)}=newname;
end

%define a searching path

searchPath=uigetdir('','Define a path where to look at');

%check for valid paths in the defined directories


count=nfiles;

for k=1:nfiles
    
    findfile=dir(fullfile(searchPath,sprintf('**\\%s',char(filelist(i(k))))));
    
    %check if we have found something and remove red color
    
    if ~isempty(findfile)
        
        rfile=findfile.name;
        rpath=findfile.folder;
        
        if ~isempty(rfile)
            
            %replace wrong path with right one
            pathList(i(k))={rpath(1,:)};
            
            %remove red color
            content=cellstr(get(handles.listbox1,'string'));
            content(i(k))={rfile(1,:)};
            set(handles.listbox1,'string',content)
        else
            count=count-1;
        end
    else
        count=count-1;
    end
end

handles.pathList=pathList;
    
if nfiles>count
    color='r';
else
    color='k';
end

msg=['Found ' num2str(count) ' paths, out of ' num2str(nfiles) ' missing'];
set(handles.text_mssg,'string',msg,'ForegroundColor',color);

guidata(hObject, handles);


% --------------------------------------------------------------------
function menu_asd_dir_Callback(hObject, eventdata, handles)
% hObject    handle to menu_asd_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
folder_name=uigetdir;

if folder_name==0
    msg = '!!No folder selected!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

%look for .asd files in the choosen directory
txt='/*.asd';
path=strcat(folder_name,txt);
asdfiles=dir(path);
nfiles = length(asdfiles);
[a, myhandle2asd]=gcbo;
%show the directory tree

Test_TreeView(folder_name,myhandle2asd)

if nfiles==0
    msg = '!!No ASD file found in the selected folder!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
else
    
    
    fileList= extractfield(asdfiles,'name');
    handles.pathList= extractfield(asdfiles,'folder');
    set(handles.listbox1,'String',fileList);
    
    %reset listbox previous selections
    set(handles.listbox1,'Value',1);
    set(handles.text_mssg,'string',folder_name,'ForegroundColor','k')
end
% set(handles.listbox2,'Value',1);
% set(handles.listbox2,'String',{});

%set serching path and define selected files path

handles.folder=folder_name;

pathFlag=get(handles.menu_path_last,'Checked');

if strcmp(pathFlag,'on')
    
    cd(folder_name)
end

guidata(hObject, handles);

% --------------------------------------------------------------------
function menu_asd_files_Callback(hObject, eventdata, handles)
% hObject    handle to menu_asd_files (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file_name,folder_name]=uigetfile('*.asd','Select an .asd file (shift+mouse for multiple selection)',...
    'MultiSelect','on');


if folder_name==0
    msg = '!!No file selected!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

%look for .asd files in the choosen directory
txt='.asd';
check=contains(file_name,txt);

nfiles=sum(check);


if nfiles==0
    msg = '!!No ASD file found in the selected folder!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end


folder_names(1:nfiles)={folder_name};
handles.pathList= folder_names;
set(handles.listbox1,'String',file_name);

%reset listbox previous selections 
set(handles.listbox1,'Value',1);

% set(handles.listbox2,'Value',1);
% set(handles.listbox2,'String',{});

%set serching path and define selected files path
set(handles.text_mssg,'string',folder_name,'ForegroundColor','k')
handles.folder=folder_name(1);

pathFlag=get(handles.menu_path_last,'Checked');

if strcmp(pathFlag,'on')
    
    cd(folder_name)
end

guidata(hObject, handles);


% --------------------------------------------------------------------
function menu_addALL_Callback(hObject, eventdata, handles)
% hObject    handle to menu_addALL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%retrive the list of file names and their path and number of elements in
%listbox1
copyname=cellstr(get(handles.listbox1,'String'));
copypath=handles.pathList;

n_copyname=numel(copyname);
n_copypath=numel(copypath);

%chechk everything is ok, if not issue an error
if isempty(copyname)||isempty(copypath)
    msg = '!!No file or path found to be copied found!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
elseif n_copyname~=n_copypath
    msg = '!!Internal error. Number of paths do not match number of file names!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

%retrive the list of file names and their path and number of elements in
%listbox2 and add listbox1 elements

currentnames=get(handles.listbox2,'String');

if ~isfield(handles,'pathList2')
    handles.pathList2=[];
    guidata(hObject,handles);
    handles=guidata(hObject);
end

currentpaths=handles.pathList2;

%cehck if there are elements and set indexes for playlist2 and copy

if isempty(currentpaths)||isempty(currentnames)
    currentnames=copyname;
    currentpaths=copypath;
else
   currentnames(end+1:end+n_copyname)=copyname;
    currentpaths(end+1:end+n_copyname)=copypath;
end

set(handles.listbox2,'string',currentnames);
handles.pathList2=currentpaths;

msg = ['Succesfully added ' num2str(n_copyname) ' files to playlist!'];
set(handles.text_mssg,'string',msg,'ForegroundColor','k')
fprintf('%s\n',msg)
   

guidata(hObject, handles);


% --------------------------------------------------------------------
function menu_load_smat_Callback(hObject, eventdata, handles)
% hObject    handle to menu_load_smat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_smat_dir_Callback(hObject, eventdata, handles)
% hObject    handle to menu_smat_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
folder_name=uigetdir;

if folder_name==0
    msg = '!!No folder selected!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

%look for .asd files in the choosen directory
txt='/*.smat';
path=strcat(folder_name,txt);
smatfiles=dir(path);
nfiles = length(smatfiles);
[a, myhandle2asd]=gcbo;
%show the directory tree
Test_TreeView(folder_name,myhandle2asd,'.smat')

if nfiles==0
    msg = '!!No ASD file found in the selected folder!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
else
    
    
    fileList= extractfield(smatfiles,'name');
    handles.pathList= extractfield(smatfiles,'folder');
    set(handles.listbox1,'String',fileList);
    
    %reset listbox previous selections
    set(handles.listbox1,'Value',1);
    set(handles.text_mssg,'string',folder_name,'ForegroundColor','k')
end
% set(handles.listbox2,'Value',1);
% set(handles.listbox2,'String',{});

%set serching path and define selected files path

handles.folder=folder_name;

pathFlag=get(handles.menu_path_last,'Checked');

if strcmp(pathFlag,'on')
    
    cd(folder_name)
end

guidata(hObject, handles);

% --------------------------------------------------------------------
function menu_smat_files_Callback(hObject, eventdata, handles)
% hObject    handle to menu_smat_files (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file_name,folder_name]=uigetfile('*.smat','Select an .smat file (shift+mouse for multiple selection)',...
    'MultiSelect','on');


if folder_name==0
    msg = '!!No file selected!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

%look for .asd files in the choosen directory
txt='.smat';
check=contains(file_name,txt);

nfiles=sum(check);


if nfiles==0
    msg = '!!No ASD file found in the selected folder!!';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end


folder_names(1:nfiles)={folder_name};
handles.pathList= folder_names;
set(handles.listbox1,'String',file_name);

%reset listbox previous selections 
set(handles.listbox1,'Value',1);

% set(handles.listbox2,'Value',1);
% set(handles.listbox2,'String',{});

%set serching path and define selected files path
set(handles.text_mssg,'string',folder_name,'ForegroundColor','k')
handles.folder=folder_name(1);

pathFlag=get(handles.menu_path_last,'Checked');

if strcmp(pathFlag,'on')
    
    cd(folder_name)
end

guidata(hObject, handles);


% --------------------------------------------------------------------
function menu_concHR_Callback(hObject, eventdata, handles)
% hObject    handle to menu_concHR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%get selection on listbox 1 and check it for being HR type file
contents = cellstr(get(handles.listbox1,'String')); 
filename=contents{get(handles.listbox1,'Value')};

TF0 = contains(filename,'_HR_');
TF1  = contains(filename,'.asd');

%get the directory to retrive the file
if isfield(handles, 'pathList')
    pathList=handles.pathList;
    folder_name=pathList{get(handles.listbox1,'Value')};
else
    msg = 'Please select a folder!!.';
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end

if TF0 && TF1  
    
    %extract partial name
    k = strfind(filename,'_HR_');
    
    if numel(k)>1
        return
    end
    
    leadname = extractBetween(filename,1,k+3);
    myname = extractBetween(filename,1,k-1);
    
    %get all the files with partial name
    TF2=contains(string(contents),string(leadname));
    myfiles=contents(TF2);
    
    %read each files one by one, concatenate and display them
    
    for i=1:numel(myfiles)
        filepath = string(fullfile(folder_name,myfiles(i)));
        [video1(:,:,i), header, video2(:,:,i)]=loadASD(filepath);
        
    end
    
    
    myname_ch1=string(strcat('Ch1_',myname,'.smat'));
    myname_ch2=string(strcat('Ch2_',myname,'.smat'));
    
    viewer_GUI(video1,myname_ch1,header);
    viewer_GUI(video2,myname_ch2,header);
    
    
    
else
    msg='Not an HR type file or .asd';    
    set(handles.text_mssg,'string',msg,'ForegroundColor','r')
    warning(msg)
    return
end
     
