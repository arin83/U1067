function R = loadColormap
% Returns my custom colormap
R = load('lutAFM');
R = R.AFMLUT;