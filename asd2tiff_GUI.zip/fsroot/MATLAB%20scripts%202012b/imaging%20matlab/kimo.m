function [c]=kimo(video,range,cmap,frame)

nFrame=size(video,3);

prompt={'first frame',...
        'last frame','how many lines','sampling'};
name='frame selection';
numlines=1;
samplingDefault=min([size(video,1) size(video,2)])-0.2*min([size(video,1) size(video,2)]);

defaultanswer={'1',num2str(nFrame),'1',num2str(samplingDefault)};

options.Resize='on';
options.WindowStyle='normal';

answer=str2double(inputdlg(prompt,name,numlines,defaultanswer,options));

start=answer(1,1);
stop=answer(2,1);
nLines=answer(3,1);
sampling=answer(4,1);
offset=-10;

hf=figure(1);
colormap(cmap)
displayImage(video(:,:,frame),range);

delta=stop-start+1;
c=single(zeros(sampling,delta,delta,nLines))+offset;
c2=single(zeros(delta,delta,delta,nLines))+100;

topV=max(max(max(video)));
minV=min(min(min(video)));

for i=1:nLines 

figure(1)

[xp yp test xi yi] = improfile(sampling);
line(imgca(hf),xi,yi,'color','w','LineWidth',1.5)
text(imgca(hf),xi(1)-10,yi(1)-10,num2str(i),'color','w');

%try to extrace the maximum over time in the kimograph

counter=1;

for k=start:stop
    if counter>1
        c(:,:,counter,i)=c(:,:,counter-1,i);
    end
    myLine=improfile(flipud(video(:,:,k)), xi, yi,sampling);
    c(:,counter,counter,i)=myLine;
    
    fdime=resample(myLine,delta,sampling);
    if numel(fdime)>delta
        fdime(delta+1:end)=[];
    end
    
    
    fdime=round(fdime*(delta/topV));       
    fdime(fdime<1)=1;
    fdime(:,2)=1:length(fdime);
    
    tc2=single(zeros(delta))+topV;
    idx = sub2ind([delta delta],fdime(:,1),fdime(:,2));
%     try
%         idx2 = sub2ind([delta delta],fdime(:,1)-1,fdime(:,2));
%     catch
%         idx2=idx;
%     end
%     idx3 = sub2ind([delta delta],fdime(:,1)+1,fdime(:,2));
%     try
%         idx4 = sub2ind([delta delta],fdime(:,1)-2,fdime(:,2));
%     catch
%         idx4=idx3;
%     end
%     idx5 = sub2ind([delta delta],fdime(:,1)+2,fdime(:,2));
    
    SE=ones(ceil(delta/40),ceil(delta/90));
    tc2(idx) = 0; tc2=ordfilt2(tc2,1,SE);
    tc2(tc2==0)=minV;
%     tc2(idx2) = topV*2;tc2(idx3) = topV*2;
%     tc2(idx4) = topV*2;    tc2(idx5) = topV*2;
    
    c2(:,:,counter,i)=flipud(tc2);
    
    counter=counter+1;
end
    

end

c=vertcat(c,c2);
end
    
        