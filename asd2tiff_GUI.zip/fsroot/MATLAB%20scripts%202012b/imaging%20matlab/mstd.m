function std=mstd(video)

prompt = {'moving std n'};
nstd=str2double(inputdlg(prompt));

std=movstd(video,nstd,0,3);


