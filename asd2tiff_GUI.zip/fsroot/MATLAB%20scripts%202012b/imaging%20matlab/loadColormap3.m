function R = loadColormap3
% Returns my custom colormap
R = load('lutAFM');
R = R.inferno;