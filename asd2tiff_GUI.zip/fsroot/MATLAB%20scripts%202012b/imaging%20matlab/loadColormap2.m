function R = loadColormap2
% Returns my custom colormap
R = load('lutAFM');
R = R.Slimer;